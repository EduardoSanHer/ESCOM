package juegoahorcado;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * Integrantes
 * Hernandez Sandoval Eduardo
 * Ruvalcaba Flores Martha Catalina
 */

//Librerias 


public class Cliente {

    public static void main(String[] args){
        int intentos = 5; //intentos del cliente
        int resultado = 0, intentosAux = 0;
        char letra = ' ';
        Scanner sc = new Scanner(System.in);
        
        try{
            Socket cl = new Socket("::1",1357);
            System.out.println("Conexion establecida. Recibiendo datos..");
            
            ReglasJuego rj = new ReglasJuego();
            ObjectOutputStream oos = new ObjectOutputStream(cl.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(cl.getInputStream()); //Lectura del Objeto *deserializa datos primitivos y objetos escritos

            System.out.println("Seleccione la dificultad del juego \n 1.- Facil \n 2.- Normal \n 3.- Dificil \n");
            int nivel = sc.nextInt();
            Objeto obj = new Objeto(nivel+ ""); //Crea Objeto para seleccionar la dificultad, es de tipo String, se agrega al final ""
            oos.writeObject(obj); //escribe el contenido del objeto en oos
            oos.flush(); //libera el buffer
            
            System.out.println("Palabra recibida desde " + cl.getInetAddress() + " con el Puerto:" + cl.getPort());
            System.out.println("Vidas del jugador: "+intentos);
            System.out.println("Adivina la palabra siguiente");
            
            Objeto objPalabra = (Objeto)ois.readObject(); //Crea objetoPalabra 
            String palabraJuego = objPalabra.getPalabra(); //asignamos a palabraJuego la palabra obtenida de acuerdo a la dificultad
            String guionBajo = rj.guion(palabraJuego);  // llamamos al metodo guion de la clase ReglasJuego para contar el numero de guiones con espacios de la palabra obtenida
            
            char[] tguion = guionBajo.toCharArray(); //convertir el guion bajo en un arreglo de caracteres
            char[] treemplazo;
            
            rj.convertirguion(tguion); // reglas del juego llama al metodo convertirguion el arreglo de caracteres tguion
            sc.nextLine();
            
            while(intentos > 0){ //el ciclo depende del numero de intentos, sino termina el juego
                
                System.out.println("\nIngrese una letra");
                String lecturaCaracter = sc.nextLine();
                letra = lecturaCaracter.charAt(0); //retorna el valor de la posicion 0
                //System.out.println("CLIENTE "+ lecturaCaracter);
                //System.out.println("posicion 0: "+ letra);
                String letraUsada = rj.getpalabraUsada();
                if(letraUsada.length() > 0){
                    while (letraUsada.indexOf(letra)!= -1){
                        System.out.println("Letra repetida,ingresa otra diferente");
                        System.out.println("\nIngrese una letra");
                        lecturaCaracter = sc.nextLine();
                        letra = lecturaCaracter.charAt(0); //retorna el valor de la posicion 0
                    }
                }
                
                rj.setpalabraUsada(letraUsada + letra);
                intentosAux = 0; 
                tguion = guionBajo.toCharArray();
                treemplazo = objPalabra.getPalabra().toCharArray();
                
                for(int c = 0; c < objPalabra.getPalabra().length(); c++ ){
                    //ciclo para reemplazar guion por caracter
                    if(treemplazo[c] == letra){
                        tguion[c] = letra; //reemplaza letra por guion  
                        intentosAux++;
                    }                    
                }
                if(intentosAux == 0){
                    intentos--;
                }
                guionBajo = String.valueOf(tguion); //convierte tguion char -> String
                rj.convertirguion(tguion);
                System.out.println("\nVidas restantes: "+intentos); //
                
                if(guionBajo.equals(palabraJuego)){
                    resultado = 1;
                    break;
                }
            }
            if(resultado == 1){
                System.out.println("Has ganado el juego");
                obj = new Objeto("Ha ganado el usuario");
                oos.writeObject(obj);
                oos.flush();
            }else{
                System.out.println("Has perdido el juego");
                obj = new Objeto("Ha perdido el usuario");
                oos.writeObject(obj);
                oos.flush();
            }

            oos.close();
            ois.close();
            cl.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegoahorcado;

/**
 *
 * @author Martha
 */
public class ReglasJuego {
    String palabraUsada = "", palabraGuion = "";
    
    public void setpalabraUsada(String palabraGuion){
         this.palabraUsada = palabraGuion;
    }
    
    public String getpalabraUsada(){
        return palabraUsada;
    }
    
    public String guion(String palabra) {
        for (int x = 0; x < palabra.length(); x++) {
            palabraGuion = palabraGuion + "_";  
        }
        return palabraGuion;
    }
    
    public void convertirguion(char[] palabra){
        for (int y = 0; y < palabra.length; y++) {
                System.out.print(palabra[y] + " ");
            }
    }
    
    
 


}

package juegoahorcado;

//Librerias
import java.io.Serializable;
/**
 * Integrantes
 * Hernandez Sandoval Eduardo
 * Ruvalcaba Flores Martha Catalina
 */
public class Objeto implements Serializable{
    //La serialización es la transformación de un objeto en una secuencia de bytes que pueden ser posteriormente leídos para reconstruir el objeto original.
    
    private String palabras;

    public Objeto(String palabras) {
        this.palabras = palabras;
    }
    public void setPalabra(String palabras) { // insertar palabra
        this.palabras = palabras;
    }
    
    public String getPalabra() { //obtener palabra
        return palabras;
    }
    
}
package juegoahorcado;

//Librerias 
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

/**
 * Integrantes
 * Hernandez Sandoval Eduardo
 * Ruvalcaba Flores Martha Catalina
 */

public class Servidor  {
    public static void main(String[] args){
        
    String [] facil = {"perro","casa","ojo","pobre","loro","gato","vela","aire","pluma","pollo"};
    String [] normal = {"momento","extraño","reconocer","mecanismo","capacidad","habilidad","comunidad","comprobar","divertido","costumbre"};
    String [] dificil = {"tener la conciencia limpia es señal de mala memoria","las bodas son básicamente funerales con un pastel","a veces la ciencia es mucho más arte que ciencia y mucha gente no entiende eso",
                        "ni lo entiendo ni necesito entenderlo","podríamos disfrutarlo un rato mira lo loco que es todo","antes o después hay que saber despedirse",
                        "cuando sabes que nada importa el universo es tuyo y nunca he visto un universo al que le gustara eso","no me vas a creer porque casi nunca pasa pero cometí un error","la vida está hecha de pequeñas concesiones","cuando la gente inteligente está feliz deja de reconocerse a sí misma"};

        try{
            ServerSocket s = new ServerSocket(1357); //Crea un socket de servidor, vinculado al puerto especificado
            
            //SO_REUSEPORT permite que múltiples sockets se vinculen a la misma combinación de dirección y puerto
            s.setReuseAddress(true);            
            boolean reuseAdd = s.getReuseAddress();
            System.out.println("estado de la opcion SO_REUSEADDR: "+reuseAdd); 
            
            System.out.println("Servidor iniciado, esperando al cliente ..."); //mensaje a la consola sobre el Servidor
            
            //for
            for(;;){ //declaracion de un bucle infinito
                String palabra = "";
                Random ran = new Random();
                int numran = ran.nextInt(10);
                
                Socket cl = s.accept(); //Escucha la conexión que se realizará con este socket y la acepta.
                System.out.println("Cliente conectado.. enviando datos.."); //mensaje a la consola sobre el Cliente
                
                ObjectOutputStream oos = new ObjectOutputStream(cl.getOutputStream()); //Escritura tipo de dato primitivo del Objeto
                ObjectInputStream ois = new ObjectInputStream(cl.getInputStream()); //Lectura del Objeto *deserializa datos primitivos y objetos escritos
                
                Objeto nivelC = (Objeto)ois.readObject(); // castea la referencia de tipo ObjectInputStream asignandola a una referencia de tipo Objetivo , * readObject = lee los objetos del flujo de ois, en el mismo orden en el que ha sido escritos
                int nivel = Integer.parseInt(nivelC.getPalabra()); // se obtiene el valor convertido a tipo entero
                
                System.out.println("Cliente escoge el nivel: " + nivel);
                
                //opcion del nivel de dificultad
                if (nivel == 1) {
                    palabra = facil[numran];
                }else if (nivel == 2) {
                    palabra = normal[numran];
                }else if (nivel == 3) {
                    palabra = dificil[numran];
                }
                System.out.println("palabra obtenida: " + palabra);
                //Escribir letras o palabras para adivinar la palabra
                Objeto palabraC = new Objeto(palabra);
                oos.writeObject(palabraC);
                oos.flush();
                
                Objeto resultado = (Objeto)ois.readObject();
                if(resultado.getPalabra().equals("Ha ganado el usuario")){
                    System.out.println("Ha ganado el usuario");
                }else if(resultado.getPalabra().equals("Ha perdido el usuario")){
                    System.out.println("Ha perdido el usuario");
                }
                
                ois.close();
                oos.close();
                cl.close();
                
            }
            //for
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

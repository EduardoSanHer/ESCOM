package chat;
import java.net.*;
import java.io.*;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * @author Axel
 */

/** Modificado por:
 * Ruvalcaba Flores Martha Catalina
 * Sandoval Hernández Eduardo
 */

class Send extends Thread{
    MulticastSocket socket;
    BufferedReader br;
    String user_id;
    
    public Send(MulticastSocket m, BufferedReader br, String user_id){
        this.socket=m;
        this.br=br;
        this.user_id=user_id;
        
    }
    
    
    public void run(){
     try{
        //BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
        String dir = "230.1.1.1";
        //String dir = "231.1.1.1";
        String dir6 = "ff3e::1234:1";
        int pto=4000;
        //int pto=1234;
        InetAddress gpo = InetAddress.getByName(dir6);

        ///// Envía mensaje de que se ha entrado al chat
            String mensajeinicio= "[Ha entrado al chat]";
            byte[] b_inicio = mensajeinicio.getBytes();
            byte[] new_b_inicio;
            StringTokenizer st_inicio = new StringTokenizer (mensajeinicio);
            ByteArrayOutputStream waos_inicio = new ByteArrayOutputStream();
            DataOutputStream dos_inicio = new DataOutputStream(waos_inicio);
            String init = "[INICIO:"+user_id+"]";
            byte[] user_temp_inicio = init.getBytes();
            byte[] dest_temp_inicio;
            dos_inicio.writeInt(user_temp_inicio.length);
            dos_inicio.write(user_temp_inicio);
            String s2_temp = st_inicio.nextToken();
            if(s2_temp.contains("<") && s2_temp.contains(">")){
                String s2temp = s2_temp.replaceAll("<","");
                s2temp = s2temp.replaceAll(">","");
                dest_temp_inicio = s2temp.getBytes();
                mensajeinicio = mensajeinicio.replaceAll(s2_temp, "");
            }
            else
                dest_temp_inicio = "all".getBytes();
            dos_inicio.writeInt(dest_temp_inicio.length);
            dos_inicio.write(dest_temp_inicio);
            
            new_b_inicio = mensajeinicio.getBytes();
            dos_inicio.writeInt(new_b_inicio.length);
            dos_inicio.write(new_b_inicio);
            dos_inicio.flush();
            
            byte[] tmp2_inicio = waos_inicio.toByteArray();
            DatagramPacket p_inicio = new DatagramPacket(tmp2_inicio,tmp2_inicio.length,gpo,pto);
            socket.send(p_inicio);
        /////
        
        for(;;){
            //System.out.println("Escribe un mensaje para ser enviado:");
            String mensaje= br.readLine();
            byte[] b = mensaje.getBytes();
            byte[] new_b;
            StringTokenizer st = new StringTokenizer (mensaje);
            ByteArrayOutputStream waos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(waos);
            byte[] user_temp = user_id.getBytes();
            byte[] dest_temp;
            dos.writeInt(user_temp.length);
            dos.write(user_temp);
            String s2 = st.nextToken();
            if(s2.contains("<") && s2.contains(">")){
                String s2temp = s2.replaceAll("<","");
                s2temp = s2temp.replaceAll(">","");
                dest_temp = s2temp.getBytes();
                mensaje = mensaje.replaceAll(s2, "");
            }
            else
                dest_temp = "all".getBytes();
            dos.writeInt(dest_temp.length);
            dos.write(dest_temp);
            
            new_b = mensaje.getBytes();
            dos.writeInt(new_b.length);
            dos.write(new_b);
            dos.flush();
            
            byte[] tmp2 = waos.toByteArray();
            //DatagramPacket p = new DatagramPacket(b,b.length,gpo,pto);
            DatagramPacket p = new DatagramPacket(tmp2,tmp2.length,gpo,pto);
            socket.send(p);
        }//for
     }catch(Exception e){
         e.printStackTrace();
     }//catch
     }//run
}//class

class Receive extends Thread{
    MulticastSocket socket;
    String user_id;
    
    public Receive(MulticastSocket m, String user_id){
        this.socket=m;
        this.user_id=user_id;
    }
    public void run(){
        try{
            String dir = "230.1.1.1";
            //String dir = "231.1.1.1";
            String dir6 = "ff3e::1234:1";
            int pto=4000;
            //int pto=1234;
            InetAddress gpo = InetAddress.getByName(dir6);
            
            
            for(;;){
                DatagramPacket p = new DatagramPacket(new byte[65535],65535);
                //System.out.println("Listo para recibir mensajes...");
                socket.receive(p);
                //String msj = new String(p.getData(),0,p.getLength());
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(p.getData()));
                int tam_emisor = dis.readInt();
                byte[] emisor_b = new byte[tam_emisor];
                int x = dis.read(emisor_b);
                int tam_receptor = dis.readInt();
                byte[] receptor_b = new byte[tam_receptor];
                int y = dis.read(receptor_b);
                int tam_msj = dis.readInt();
                byte[] msj_b = new byte[tam_msj];
                int z = dis.read(msj_b);
                
                String emisor = new String(emisor_b);
                String receptor = new String(receptor_b);
                String msj = new String(msj_b);
                
                if(!emisor.equals(user_id)){
                    if(receptor.equals("all"))
                        System.out.println("<msj><"+emisor+">"+msj);
                    else if(receptor.equals(user_id))
                        System.out.println("<privado><"+emisor+">"+"<"+receptor+">"+msj);
                    if(emisor.contains("[INICIO:")){
                        String mensajesaludo= "[Bienvenido, me encuentro actualmente en el chat]";
                        byte[] b_inicio = mensajesaludo.getBytes();
                        byte[] new_b_saludo;
                        ByteArrayOutputStream waos_saludo = new ByteArrayOutputStream();
                        DataOutputStream dos_saludo = new DataOutputStream(waos_saludo);
                        String user_saludo = user_id;
                        byte[] user_temp_saludo = user_saludo.getBytes();
                        byte[] dest_temp_saludo;
                        dos_saludo.writeInt(user_temp_saludo.length);
                        dos_saludo.write(user_temp_saludo);
                        
                        String dest_saludo = emisor.replaceAll("INICIO:", "");
                        dest_saludo = dest_saludo.replaceAll("]", "");
                        dest_saludo = dest_saludo.replaceAll("\\[", "");
                        dest_temp_saludo = dest_saludo.getBytes();
                        dos_saludo.writeInt(dest_temp_saludo.length);
                        dos_saludo.write(dest_temp_saludo);

                        new_b_saludo = mensajesaludo.getBytes();
                        dos_saludo.writeInt(new_b_saludo.length);
                        dos_saludo.write(new_b_saludo);
                        dos_saludo.flush();

                        byte[] tmp2_saludo = waos_saludo.toByteArray();
                        DatagramPacket p_saludo = new DatagramPacket(tmp2_saludo,tmp2_saludo.length,gpo,pto);
                        socket.send(p_saludo);
                    }
                        
                }
                //System.out.println("Mensaje recibido: "+msj);
            } //for
        }catch(Exception e){
            e.printStackTrace();
        }//catch
    }//run
}//class




public class ChatP2P_Console {
    
    static void despliegaInfoNIC(NetworkInterface netint) throws SocketException {
        System.out.printf("Nombre de despliegue: %s\n", netint.getDisplayName());
        System.out.printf("Nombre: %s\n", netint.getName());
        String multicast = (netint.supportsMulticast())?"Soporta multicast":"No soporta multicast";
        System.out.printf("Multicast: %s\n", multicast);
        Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
        for (InetAddress inetAddress : Collections.list(inetAddresses)) {
            System.out.printf("Direccion: %s\n", inetAddress);
        }
        System.out.printf("\n");
    }

    public static void main(String[] args){
        
        String user_id = "";
        Scanner leer = new Scanner(System.in);
        user_id = leer.nextLine();

        while(user_id.equals("all")){
            System.out.print("\nElija un nombre de usuario:");
            //user_id = br.readLine();
            user_id = leer.nextLine();
            if(user_id.equals("all"))
                System.out.println("\n**No puede usar ese nombre de usuario**");
        }
        System.out.println("\nSu nombre de usuario es: "+user_id);
        try{
            int pto= 4000,z=0;
            //int pto = 1234;
            
            //user_id = "XD";
            
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in,"ISO-8859-1"));
            Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface netint : Collections.list(nets)){
                System.out.print("[Interfaz "+ ++z +"]:");
                despliegaInfoNIC(netint);
            }//for
            System.out.print("\nElige la interfaz multicast:");
            int interfaz = Integer.parseInt(br.readLine());
            //NetworkInterface ni = NetworkInterface.getByName("eth2");
            NetworkInterface ni = NetworkInterface.getByIndex(interfaz);
            //br.close();
            System.out.println("\nElegiste "+ni.getDisplayName());
            

            MulticastSocket m= new MulticastSocket(pto);
            m.setReuseAddress(true);
            m.setTimeToLive(255);
            String dir= "230.1.1.1";
            //String dir= "231.1.1.1";
            String dir6 = "ff3e::1234:1";
            InetAddress gpo = InetAddress.getByName(dir6);
            //InetAddress gpo = InetAddress.getByName("ff3e:40:2001::1");
            SocketAddress dirm;
            try{
                dirm = new InetSocketAddress(gpo,pto);
            }catch(Exception e){
                e.printStackTrace();
                return;
            }//catch
            m.joinGroup(dirm, ni);
            System.out.println("Socket unido al grupo "+gpo);


            Receive r = new Receive(m, user_id);
            Send e = new Send(m, br, user_id);
            //inicio i = new inicio(m, br, user_id);
            //i.run();
            e.setPriority(10);
            r.start();
            e.start();
            r.join();
            e.join();
        }catch(Exception e){}
    }//main  
}

package Flujo_Datagrama;

import java.net.*;
import java.io.*;
import java.util.Arrays;

/**
 * @author Ruvalcaba Flores Martha Catalina
 * @author Sandoval Hernández Eduardo
**/

public class ClienteDM {
    public static void main(String[] args){
        try{  
            int pto=1234;
            String dir="127.0.0.1";
            InetAddress dst= InetAddress.getByName(dir);
            int tam = 10;
            int contador = 0;
            BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
            DatagramSocket cl = new DatagramSocket();
            while(true){
                System.out.println("Escribe un mensaje, <Enter> para enviar, \"salir\" para terminar");
                String msj = br.readLine();
                contador = 0;
                if(msj.compareToIgnoreCase("salir")==0){
                    System.out.println("termina programa");
                    br.close();
                    cl.close();
                    System.exit(0);
                }else{
                    byte[]b = msj.getBytes();
                    String eco_msg = "";
                    if(b.length>tam){
                        byte[]b_eco = new byte[b.length];
                        //System.out.println("b_eco: "+b_eco.length+" bytes");
                        int tp = (int)(b.length/tam);
                        for(int j=0;j<tp;j++){
                            //byte[] tmp = new byte[tam];
                            byte []tmp=Arrays.copyOfRange(b, j*tam, ((j*tam)+(tam)));
                            //System.out.println("tmp tam "+tmp.length);
                            
                            contador++;
                            //System.out.println(contador);
                            ByteArrayOutputStream waos = new ByteArrayOutputStream();
                            DataOutputStream dos = new DataOutputStream(waos);
                            dos.writeInt(contador);
                            dos.writeInt(tmp.length);
                            dos.write(tmp);
                            dos.flush();
                            byte[] tmp2 = waos.toByteArray();
                            DatagramPacket p= new DatagramPacket(tmp2,tmp2.length,dst,pto);
                            cl.send(p);
                            System.out.println("Enviando fragmento "+(j+1)+" de "+tp+"\ndesde:"+(j*tam)+" hasta "+((j*tam)+(tam)));
                            
                            //DatagramPacket p1= new DatagramPacket(new byte[tam],tam);
                            DatagramPacket p1 = new DatagramPacket(new byte[65535],65535);
                            cl.receive(p1);
                            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(p1.getData()));
                            int nn = dis.readInt();
                            int nsize = dis.readInt();
                            byte [] l = new byte[nsize];
                            int f = dis.read(l);
                            String eco_msg_p = new String(l);
                            //System.out.println("Eco "+contador+" ::: "+eco_msg_p);
                            eco_msg = eco_msg.concat(eco_msg_p);
                            
                            /*
                            byte[]bp1 = p1.getData();
                            for(int i=0; i<tam;i++){
                                //System.out.println((j*tam)+i+"->"+i);
                                b_eco[(j*tam)+i]=bp1[i];
                            }//for
                            */
                            
                            
                            dos.close();
                            
                        }//for
                        if(b.length%tam>0){ //bytes sobrantes  
                            int sobrantes = b.length%tam;
                            System.out.println("sobrantes:"+sobrantes);
                            System.out.println("b:"+b.length+"ultimo pedazo desde "+tp*tam+" hasta "+((tp*tam)+sobrantes));
                            byte[] tmp = Arrays.copyOfRange(b, tp*tam, ((tp*tam)+sobrantes));
                            //System.out.println("tmp tam "+tmp.length);
                            
                            contador++;
                            ByteArrayOutputStream waos = new ByteArrayOutputStream();
                            DataOutputStream dos = new DataOutputStream(waos);
                            dos.writeInt(contador);
                            dos.writeInt(tmp.length);
                            dos.write(tmp);
                            dos.flush();
                            byte[] tmp2 = waos.toByteArray();
                            DatagramPacket p= new DatagramPacket(tmp2,tmp2.length,dst,pto);
                            cl.send(p);
                            
                            //DatagramPacket p1= new DatagramPacket(new byte[tam],tam);
                            DatagramPacket p1 = new DatagramPacket(new byte[65535],65535);
                            cl.receive(p1);
                            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(p1.getData()));
                            int nn = dis.readInt();
                            int nsize = dis.readInt();
                            byte [] l = new byte[nsize];
                            int f = dis.read(l);
                            String eco_msg_p = new String(l);
                            eco_msg = eco_msg.concat(eco_msg_p);
                            
                            //System.out.println("Sobrantes::: "+eco_msg_p);
                            //byte[]bp1 = p1.getData();
                            /*
                            byte[]bp1 = l;
                            for(int i=0; i<sobrantes;i++){
                                //System.out.println((tp*tam)+i+"->"+i);
                                b_eco[(tp*tam)+i]=bp1[i];
                            }//for
                            */
                            
                            dos.close();
                            
                        }//if

                        //String eco = new String(b_eco);
                        System.out.println("Eco recibido: "+eco_msg);
                    }else{
                        DatagramPacket p=new DatagramPacket(b,b.length,dst,pto);
                        cl.send(p);
                        DatagramPacket p1 = new DatagramPacket(new byte[65535],65535);
                        cl.receive(p1);
                        String eco = new String(p1.getData(),0,p1.getLength());
                        System.out.println("Eco recibido: "+eco);
                    }//else
                }//else
            }//while
        }catch(Exception e){
            e.printStackTrace();
        }//catch
    }
    
}

package Flujo_Datagrama;

import java.net.*;
import java.io.*;

/**
 * @author Ruvalcaba Flores Martha Catalina
 * @author Sandoval Hernández Eduardo
**/

public class ServidorDM {
    public static void main(String[] args){
        try{
            int pto=1234;
            String msj="";
            DatagramSocket s = new DatagramSocket(pto);
            s.setReuseAddress(true);
            int numero_paquete,size,x;
            byte [] b;
            System.out.println("Servidor iniciado: Esperando una conexion...");
            for(;;){
                byte[] temp = new byte[65535];
                DatagramPacket p = new DatagramPacket(temp,temp.length);
                s.receive(p);
                
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(p.getData()));
                numero_paquete = dis.readInt();
                size = dis.readInt();
                b = new byte[size];
                x = dis.read(b);
                //msj = new String(p.getData(),0,p.getLength());
                msj = new String(b);
                
                /*
                ByteArrayOutputStream waos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(waos);
                dos.writeInt(numero_paquete);
                dos.writeInt(size);
                dos.write(temp);
                dos.flush();
                byte[] tmp2 = waos.toByteArray();
                */
                
                //msj = new String(p.getData(),0,p.getLength());
                System.out.println("Se ha recibido el siguiente mensaje desde"+p.getAddress()+":"+p.getPort()+" con el numero de paquete: "+numero_paquete+" con el mensaje: "+msj);
                s.send(p);
                
                dis.close();
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
}
